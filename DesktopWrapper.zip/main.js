// A website in its own Windows window. Settings come from config.json (written during the build).
const { app, BrowserWindow, Menu, shell, session, clipboard } = require('electron');
const path = require('path');
const fs = require('fs');

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
const START = new URL(cfg.url);
if (START.protocol !== 'https:') { throw new Error('The website address must start with https://'); }
const SITE_HOST = START.hostname.replace(/^www\./, '');
// Payment and sign-in pages stay inside the app so checkout is not interrupted
const STAY_HOSTS = ['paystack.com', 'paystack.co', 'flutterwave.com', 'stripe.com', 'paypal.com', 'google.com', 'accounts.google.com', 'facebook.com', 'apple.com', 'microsoftonline.com', 'live.com', 'recaptcha.net', 'gstatic.com'];

function hostMatches(host, base) { return host === base || host.endsWith('.' + base); }
function isInternal(u) {
  try {
    const x = new URL(u);
    if (x.protocol !== 'https:' && x.protocol !== 'http:') return false;
    const h = x.hostname.replace(/^www\./, '');
    return hostMatches(h, SITE_HOST) || STAY_HOSTS.some((b) => hostMatches(h, b));
  } catch (e) { return false; }
}
function openOutside(u) {
  try {
    const x = new URL(u);
    if (['https:', 'http:', 'mailto:', 'tel:'].includes(x.protocol)) shell.openExternal(x.toString());
  } catch (e) { /* ignore */ }
}

// One window only: opening the app again brings the first one forward
if (!app.requestSingleInstanceLock()) { app.quit(); }

const stateFile = () => path.join(app.getPath('userData'), 'window.json');
function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch (e) { return {}; }
}
function saveState(win) {
  try {
    const b = win.getNormalBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ ...b, max: win.isMaximized() }));
  } catch (e) { /* ignore */ }
}

let win = null;

function createWindow() {
  const st = loadState();
  win = new BrowserWindow({
    width: st.width || 1200, height: st.height || 800, x: st.x, y: st.y,
    minWidth: 420, minHeight: 500,
    show: false, title: cfg.name, backgroundColor: '#ffffff',
    icon: path.join(__dirname, 'build', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true },
  });
  if (st.max) win.maximize();
  win.once('ready-to-show', () => win.show());
  win.on('page-title-updated', (e) => e.preventDefault());
  win.on('close', () => saveState(win));
  win.on('closed', () => { win = null; });
  win.loadURL(START.toString());
}

function buildMenu() {
  const tpl = [
    { label: 'App', submenu: [
      { label: 'Home', accelerator: 'Alt+Home', click: () => win && win.loadURL(START.toString()) },
      { label: 'Reload', accelerator: 'CmdOrCtrl+R', click: () => win && win.webContents.reload() },
      { label: 'Back', accelerator: 'Alt+Left', click: () => win && win.webContents.canGoBack() && win.webContents.goBack() },
      { label: 'Forward', accelerator: 'Alt+Right', click: () => win && win.webContents.canGoForward() && win.webContents.goForward() },
      { type: 'separator' },
      { label: 'Open in browser', click: () => win && openOutside(win.webContents.getURL()) },
      { type: 'separator' },
      { role: 'quit', label: 'Exit' },
    ] },
    { label: 'View', submenu: [
      { role: 'zoomIn', accelerator: 'CmdOrCtrl+=' }, { role: 'zoomOut' }, { role: 'resetZoom' },
      { type: 'separator' }, { role: 'togglefullscreen' },
    ] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

app.setAppUserModelId(cfg.appId); // needed for Windows notifications

app.on('second-instance', () => {
  if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});

// Rules for every page the app opens
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (e) => e.preventDefault());
  wc.setWindowOpenHandler(({ url }) => {
    if (isInternal(url)) { if (win) win.loadURL(url); } else { openOutside(url); }
    return { action: 'deny' };
  });
  wc.on('will-navigate', (e, url) => {
    if (url.startsWith('file:')) return; // our own offline page
    if (!isInternal(url)) { e.preventDefault(); openOutside(url); }
  });
  wc.on('did-fail-load', (_ev, code, _desc, failedUrl, isMain) => {
    if (!isMain || code === -3 || !win) return; // -3 = cancelled by a redirect
    win.loadFile(path.join(__dirname, 'offline.html'), { query: { u: failedUrl, c: cfg.color, n: cfg.name } });
  });
  wc.on('context-menu', (_ev, p) => {
    const items = [];
    if (p.linkURL) {
      items.push({ label: 'Open link in browser', click: () => openOutside(p.linkURL) }, { label: 'Copy link address', click: () => clipboard.writeText(p.linkURL) }, { type: 'separator' });
    }
    if (p.isEditable) items.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { type: 'separator' }, { role: 'selectAll' });
    else if (p.selectionText) items.push({ role: 'copy' });
    else items.push({ label: 'Back', enabled: wc.canGoBack(), click: () => wc.goBack() }, { label: 'Reload', click: () => wc.reload() });
    Menu.buildFromTemplate(items).popup();
  });
});

app.whenReady().then(() => {
  // Only the things a normal website needs. Everything else (USB, serial, ...) is refused.
  const allowed = new Set(['notifications', 'media', 'geolocation', 'clipboard-sanitized-write', 'fullscreen', 'pointerLock', 'mediaKeySystem']);
  session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => cb(allowed.has(permission)));
  session.defaultSession.on('will-download', (_e, item) => {
    item.once('done', (_ev, state) => { if (state === 'completed') shell.showItemInFolder(item.getSavePath()); });
  });
  buildMenu();
  createWindow();
});

app.on('window-all-closed', () => app.quit());

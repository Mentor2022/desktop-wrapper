// A website in its own Windows window. Settings come from config.json (written during the build).
const { app, BrowserWindow, Menu, shell, session, clipboard, dialog, Notification, Tray, nativeImage, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
app.setName(cfg.name); // the name people see (taskbar, menus, notifications), never the project name
const START = new URL(cfg.url);
if (START.protocol !== 'https:') { throw new Error('The website address must start with https://'); }
const SITE_HOST = START.hostname.replace(/^www\./, '');
// Payment and sign-in pages stay inside the app so checkout is not interrupted
const STAY_HOSTS = ['paystack.com', 'paystack.co', 'flutterwave.com', 'stripe.com', 'paypal.com', 'google.com', 'accounts.google.com', 'facebook.com', 'apple.com', 'microsoftonline.com', 'live.com', 'recaptcha.net', 'gstatic.com'];

function hostMatches(host, base) { return host === base || host.endsWith('.' + base); }
function isInternal(u) {
  try {
    const x = new URL(u);
    if (x.protocol !== 'https:' && x.protocol !== 'http:') return false;
    const h = x.hostname.replace(/^www\./, '');
    return hostMatches(h, SITE_HOST) || STAY_HOSTS.some((b) => hostMatches(h, b));
  } catch (e) { return false; }
}
function openOutside(u) {
  try {
    const x = new URL(u);
    if (['https:', 'http:', 'mailto:', 'tel:'].includes(x.protocol)) shell.openExternal(x.toString());
  } catch (e) { /* ignore */ }
}

// One window only: opening the app again brings the first one forward
if (!app.requestSingleInstanceLock()) { app.quit(); }

const stateFile = () => path.join(app.getPath('userData'), 'window.json');
function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch (e) { return {}; }
}
function saveState(win) {
  try {
    const b = win.getNormalBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ ...b, max: win.isMaximized() }));
  } catch (e) { /* ignore */ }
}

// The website's alert() / confirm() boxes, titled with the app's name (never the website address)
ipcMain.on('ab-dialog', (e, kind, message) => {
  const text = String(message || '').slice(0, 1500);
  try {
    if (kind === 'confirm') {
      const r = dialog.showMessageBoxSync(BrowserWindow.fromWebContents(e.sender) || undefined, { type: 'question', title: cfg.name, message: text, buttons: ['OK', 'Cancel'], defaultId: 0, cancelId: 1, noLink: true });
      e.returnValue = r === 0;
    } else {
      dialog.showMessageBoxSync(BrowserWindow.fromWebContents(e.sender) || undefined, { type: 'info', title: cfg.name, message: text, buttons: ['OK'], noLink: true });
      e.returnValue = true;
    }
  } catch (err) { e.returnValue = kind === 'confirm' ? false : true; }
});

let win = null;
let tray = null;
let quitting = false;
const START_HIDDEN = process.argv.includes('--hidden'); // started by Windows at sign-in: stay in the tray

// Small settings kept on this computer
const setFile = () => path.join(app.getPath('userData'), 'settings.json');
function loadSettings() {
  try { return { tray: true, login: false, tip: false, ...JSON.parse(fs.readFileSync(setFile(), 'utf8')) }; } catch (e) { return { tray: true, login: false, tip: false }; }
}
function saveSettings(v) { try { fs.writeFileSync(setFile(), JSON.stringify(v)); } catch (e) { /* ignore */ } }
let settings = { tray: true, login: false, tip: false };

function createWindow() {
  const st = loadState();
  win = new BrowserWindow({
    width: st.width || 1200, height: st.height || 800, x: st.x, y: st.y,
    minWidth: 420, minHeight: 500,
    show: false, title: cfg.name, backgroundColor: cfg.color,
    icon: path.join(__dirname, 'build', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true, preload: path.join(__dirname, 'preload.js') },
  });
  if (st.max) win.maximize();
  win.once('ready-to-show', () => { if (!START_HIDDEN) win.show(); });
  win.on('page-title-updated', (e) => { e.preventDefault(); win.setTitle(cfg.name); }); // always the app name, never the page address
  win.on('close', (e) => {
    saveState(win);
    if (!quitting && settings.tray && tray) { // closing the window keeps the app in the tray so messages still arrive
      e.preventDefault();
      win.hide();
      if (!settings.tip) {
        settings.tip = true; saveSettings(settings);
        if (Notification.isSupported()) new Notification({ title: cfg.name, body: 'Still running in the tray so you get new messages. Right-click the tray icon to exit.' }).show();
      }
    }
  });
  win.on('closed', () => { win = null; });
  // A coloured loading screen shows while the website opens
  win.loadFile(path.join(__dirname, 'splash.html'), { query: { n: cfg.name, c: cfg.color } });
  win.webContents.once('did-finish-load', () => { if (win) win.loadURL(START.toString()); });
}


// ───────────── update check ─────────────
// Asks the portal for the newest version (just a number, nothing about the person) and tells the user when one is ready.
const updFile = () => path.join(app.getPath('userData'), 'updates.json');
const vnum = (v) => String(v).split('.').map((n) => parseInt(n, 10) || 0);
function isNewer(a, b) {
  const x = vnum(a), y = vnum(b);
  for (let i = 0; i < 3; i++) { if ((x[i] || 0) > (y[i] || 0)) return true; if ((x[i] || 0) < (y[i] || 0)) return false; }
  return false;
}
async function checkUpdate(manual) {
  if (!cfg.updateUrl) {
    if (manual) dialog.showMessageBox(win, { type: 'info', message: 'Update checking is not set up for this app.' });
    return;
  }
  try {
    const r = await fetch(cfg.updateUrl, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
    const j = await r.json();
    const remote = String(j.version || '');
    let target = '';
    try {
      const u = new URL(String(j.url || ''));
      if (u.protocol === 'https:' && u.hostname === new URL(cfg.updateUrl).hostname) target = u.toString(); // only the owner's own portal
    } catch (e) { /* ignore */ }
    if (remote && target && isNewer(remote, cfg.version || '0.0.0')) {
      let seen = '';
      try { seen = JSON.parse(fs.readFileSync(updFile(), 'utf8')).seen || ''; } catch (e) { /* first time */ }
      if (manual || seen !== remote) {
        try { fs.writeFileSync(updFile(), JSON.stringify({ seen: remote })); } catch (e) { /* ignore */ }
        const text = 'Version ' + remote + ' of ' + cfg.name + ' is ready. You have version ' + (cfg.version || '1.0.0') + '.';
        if (win && (manual || win.isFocused())) {
          const res = await dialog.showMessageBox(win, { type: 'info', title: cfg.name, message: 'A new version is available', detail: text, buttons: ['Download', 'Later'], defaultId: 0, cancelId: 1 });
          if (res.response === 0) openOutside(target);
        } else if (Notification.isSupported()) {
          const n = new Notification({ title: cfg.name + ': new version', body: text + ' Click to download.' });
          n.on('click', () => openOutside(target));
          n.show();
        }
      }
    } else if (manual) {
      dialog.showMessageBox(win, { type: 'info', message: 'You have the newest version', detail: cfg.name + ' ' + (cfg.version || '1.0.0') });
    }
  } catch (e) {
    if (manual) dialog.showMessageBox(win, { type: 'warning', message: 'Could not check for updates', detail: 'Please check your internet connection and try again.' });
  }
}

// ───────────── messages from the owner ─────────────
// Asks the portal for new messages every few minutes (it sends nothing about the person) and shows them as Windows notifications.
const pushUrl = cfg.updateUrl ? cfg.updateUrl.replace('/version.php?', '/winpush.php?').replace('&os=win', '') : '';
const pushFile = () => path.join(app.getPath('userData'), 'messages.json');
async function checkMessages() {
  if (!pushUrl) return;
  try {
    let after = null;
    try { const v = JSON.parse(fs.readFileSync(pushFile(), 'utf8')).after; if (Number.isInteger(v) && v >= 0) after = v; } catch (e) { /* first run: start from now */ }
    const r = await fetch(pushUrl + (after === null ? '' : '&after=' + after), { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
    const j = await r.json();
    const seq = Number.isInteger(j.seq) ? j.seq : 0;
    if (after !== null && seq < after) after = 0; // the portal started over
    for (const it of (Array.isArray(j.items) ? j.items : []).slice(0, 5)) {
      if (!Notification.isSupported()) break;
      const n = new Notification({ title: String(it.title || cfg.name).slice(0, 80), body: String(it.body || '').slice(0, 240) });
      const target = typeof it.url === 'string' ? it.url : '';
      n.on('click', () => {
        showWindow();
        if (target && /^https:\/\//.test(target)) { if (isInternal(target)) { if (win) win.loadURL(target); } else openOutside(target); }
      });
      n.show();
    }
    try { fs.writeFileSync(pushFile(), JSON.stringify({ after: seq })); } catch (e) { /* ignore */ }
  } catch (e) { /* offline: try again later */ }
}

function showWindow() {
  if (!win) { createWindow(); return; }
  if (win.isMinimized()) win.restore();
  win.show(); win.focus();
}

function applyLogin() {
  try { app.setLoginItemSettings({ openAtLogin: !!settings.login, args: ['--hidden'] }); } catch (e) { /* ignore */ }
}

function buildTray() {
  try {
    const img = nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png')).resize({ width: 32, height: 32 });
    tray = new Tray(img);
  } catch (e) { tray = null; return; }
  tray.setToolTip(cfg.name);
  const menu = () => Menu.buildFromTemplate([
    { label: 'Open ' + cfg.name, click: showWindow },
    { type: 'separator' },
    { label: 'Keep running in the tray (to get messages)', type: 'checkbox', checked: !!settings.tray, click: (i) => { settings.tray = i.checked; saveSettings(settings); } },
    { label: 'Start with Windows', type: 'checkbox', checked: !!settings.login, click: (i) => { settings.login = i.checked; saveSettings(settings); applyLogin(); } },
    { label: 'Check for updates', click: () => checkUpdate(true) },
    { type: 'separator' },
    { label: 'Exit ' + cfg.name, click: () => { quitting = true; app.quit(); } },
  ]);
  tray.setContextMenu(menu());
  tray.on('click', showWindow);
  tray.on('right-click', () => tray.setContextMenu(menu()));
}

function buildMenu() {
  const tpl = [
    { label: cfg.name, submenu: [
      { label: 'Home', accelerator: 'Alt+Home', click: () => win && win.loadURL(START.toString()) },
      { label: 'Reload', accelerator: 'CmdOrCtrl+R', click: () => win && win.webContents.reload() },
      { label: 'Back', accelerator: 'Alt+Left', click: () => win && win.webContents.canGoBack() && win.webContents.goBack() },
      { label: 'Forward', accelerator: 'Alt+Right', click: () => win && win.webContents.canGoForward() && win.webContents.goForward() },
      { type: 'separator' },
      { label: 'Open in browser', click: () => win && openOutside(win.webContents.getURL()) },
      { label: 'Check for updates', click: () => checkUpdate(true) },
      { label: 'Start with Windows', type: 'checkbox', checked: !!settings.login, click: (i) => { settings.login = i.checked; saveSettings(settings); applyLogin(); } },
      { type: 'separator' },
      { label: 'Exit ' + cfg.name, click: () => { quitting = true; app.quit(); } },
    ] },
    { label: 'View', submenu: [
      { role: 'zoomIn', accelerator: 'CmdOrCtrl+=' }, { role: 'zoomOut' }, { role: 'resetZoom' },
      { type: 'separator' }, { role: 'togglefullscreen' },
    ] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

app.setAppUserModelId(cfg.appId); // needed for Windows notifications

app.on('second-instance', () => showWindow());
app.on('before-quit', () => { quitting = true; });

// Rules for every page the app opens
app.on('web-contents-created', (_e, wc) => {
  wc.on('will-attach-webview', (e) => e.preventDefault());
  wc.on('will-prevent-unload', (e) => e.preventDefault()); // leaving a page never shows a box with the website address
  wc.setWindowOpenHandler(({ url }) => {
    if (isInternal(url)) { if (win) win.loadURL(url); } else { openOutside(url); }
    return { action: 'deny' };
  });
  wc.on('will-navigate', (e, url) => {
    if (url.startsWith('file:')) return; // our own offline page
    if (!isInternal(url)) { e.preventDefault(); openOutside(url); }
  });
  wc.on('did-fail-load', (_ev, code, _desc, failedUrl, isMain) => {
    if (!isMain || code === -3 || !win) return; // -3 = cancelled by a redirect
    win.loadFile(path.join(__dirname, 'offline.html'), { query: { u: failedUrl, c: cfg.color, n: cfg.name } });
  });
  wc.on('context-menu', (_ev, p) => {
    const items = [];
    if (p.linkURL) {
      items.push({ label: 'Open link in browser', click: () => openOutside(p.linkURL) }, { label: 'Copy link address', click: () => clipboard.writeText(p.linkURL) }, { type: 'separator' });
    }
    if (p.isEditable) items.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { type: 'separator' }, { role: 'selectAll' });
    else if (p.selectionText) items.push({ role: 'copy' });
    else items.push({ label: 'Back', enabled: wc.canGoBack(), click: () => wc.goBack() }, { label: 'Reload', click: () => wc.reload() });
    Menu.buildFromTemplate(items).popup();
  });
});

app.whenReady().then(() => {
  // Only the things a normal website needs. Everything else (USB, serial, ...) is refused.
  const allowed = new Set(['notifications', 'media', 'geolocation', 'clipboard-sanitized-write', 'fullscreen', 'pointerLock', 'mediaKeySystem']);
  session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => cb(allowed.has(permission)));
  session.defaultSession.setPermissionCheckHandler((_wc, permission) => allowed.has(permission)); // lets calls list the camera and microphone
  session.defaultSession.on('will-download', (_e, item) => {
    item.once('done', (_ev, state) => { if (state === 'completed') shell.showItemInFolder(item.getSavePath()); });
  });
  settings = loadSettings();
  buildMenu();
  buildTray();
  createWindow();
  setTimeout(() => checkUpdate(false), 20000);
  setInterval(() => checkUpdate(false), 6 * 3600 * 1000);
  setTimeout(checkMessages, 30000);
  setInterval(checkMessages, 5 * 60 * 1000);
});

app.on('window-all-closed', () => { if (quitting || !settings.tray || !tray) app.quit(); });

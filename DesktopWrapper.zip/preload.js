// Runs before the website. Makes the website's alert() and confirm() boxes show the app's name
// (Windows would otherwise write the website's address in them).
const { contextBridge, ipcRenderer, webFrame } = require('electron');

contextBridge.exposeInMainWorld('__abd', {
  alert: (m) => { ipcRenderer.sendSync('ab-dialog', 'alert', String(m)); },
  confirm: (m) => ipcRenderer.sendSync('ab-dialog', 'confirm', String(m)) === true,
});

webFrame.executeJavaScript(
  "(function(){var d=window.__abd;if(!d)return;" +
  "window.alert=function(m){d.alert(m==null?'':String(m));};" +
  "window.confirm=function(m){return d.confirm(m==null?'':String(m));};})();"
).catch(function () { /* the page keeps its normal boxes */ });

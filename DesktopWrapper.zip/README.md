# DesktopWrapper

Turns a website into a Windows app (an installer `.exe`) using Electron.

* `config.json` holds the website address, name, app id and colour. The GitHub workflow writes it for each build.
* The installer is built by GitHub Actions on a Windows machine (`build-desktop.yml`). It cannot be built on a phone or on Linux.
* Links that leave the website open in the normal browser; payment and sign-in pages stay in the app.
* The window size and position are remembered, and only one copy of the app runs at a time.

To try it on a Windows PC: install Node.js, then `npm install` and `npm start`.
